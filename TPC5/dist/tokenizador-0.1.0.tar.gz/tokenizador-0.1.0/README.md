# TPC2

- Harry_Potter_adpt → Ficheiro de texto com o livro Harry Potter and the Philosopher's Stone alterado manualmente
- __init__.py → Script que tokeniza um livro
- utils.py → Script com funções auxiliares
- conf/abrev.txt → Ficheiro com abreviaturas
- conf/trans.txt → Ficheiro com traduções de keywords

- Não funciona devido a utils não estar a ser importado corretamente TODO
