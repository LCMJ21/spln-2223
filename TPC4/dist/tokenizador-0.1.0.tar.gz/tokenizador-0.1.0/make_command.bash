chmod +x tokenizador.py

cp tokenizador.py tokenizadorb

cp tokenizadorb ~/bin

export PATH=$PATH":$HOME/bin"