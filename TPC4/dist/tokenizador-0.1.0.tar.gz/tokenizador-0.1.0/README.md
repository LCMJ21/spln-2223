# TPC2

- Harry_Potter_e_A_Pedra_Filosofal copy→ Ficheiro de texto com o livro Harry Potter and the Philosopher's Stone
- Harry_Potter_adpt → Ficheiro de texto com o livro Harry Potter and the Philosopher's Stone alterado manualmente
- HP_proc → Resultado da aplicação do script tokenizador.py
- make_command.bash → Script fazer com que tokenizador.py possa ser executado como um comando
- tokenizador.py → Script que tokeniza o livro Harry Potter and the Philosopher's Stone
